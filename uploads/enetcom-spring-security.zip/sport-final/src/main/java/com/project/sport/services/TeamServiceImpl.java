package com.project.sport.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.sport.models.Team;
import com.project.sport.repository.TeamRepository;


@Service
public  class TeamServiceImpl implements TeamService {
	@Autowired
	private TeamRepository teamRepository;

	@Override
	public List<Team> getAllTeams() {
		return teamRepository.findAll() ;
	}

	@Override
	public Team updateTeam(Team teams) {
		return teamRepository.save(teams);
	}

	@Override
	public void deleteTeam(Integer id) {
		teamRepository.deleteById(id);
	}

	@Override
	public Team addTeam(Team team) {
		return teamRepository.save(team);
	}

	@Override
	public Team findById(Integer id) {
		 Optional<Team> teams = teamRepository.findById(id);
	     return  teams.isPresent() ? teams.get() : null;
	}

}
