package com.project.sport.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.sport.models.Matche;

@Repository
public interface MatcheRepository  extends JpaRepository<Matche, Integer>  {

}
