package com.project.sport.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.sport.models.Matche;
import com.project.sport.repository.MatcheRepository;

@Service
public class MatcheServiceImpl implements MatcheService {
	@Autowired
	private MatcheRepository matcheRepository;

	@Override
	public List<Matche> getAllMatches() {
		return matcheRepository.findAll() ;
	}

	@Override
	public Matche updateMatche(Matche matches) {
		return matcheRepository.save(matches);
	}

	@Override
	public void deleteMatche(Integer id) {
		matcheRepository.deleteById(id);
	}

	@Override
	public Matche addMatche(Matche matche) {
		return matcheRepository.save(matche);
	}

	@Override
	public Matche findById(Integer id) {
		 Optional<Matche> matches = matcheRepository.findById(id);
	     return  matches.isPresent() ? matches.get() : null;
	}

}
