package com.project.sport.services;

import java.util.List;

import com.project.sport.models.Player;

	public interface PlayerService {
	public List<Player> getAllPlayers();
	
	public Player updatePlayer(Player players);
	
	public void deletePlayer(Integer id);
	
	public Player  addPlayer(Player players);

	public Player findById(Integer id);
}
