package com.project.sport.services;

import java.util.List;

import com.project.sport.models.Team;


public interface TeamService {

	public List<Team> getAllTeams();
	
	public Team updateTeam(Team teams);
	
	public void deleteTeam(Integer id);
	
	public Team  addTeam(Team teams);

	public Team findById(Integer id);


}
