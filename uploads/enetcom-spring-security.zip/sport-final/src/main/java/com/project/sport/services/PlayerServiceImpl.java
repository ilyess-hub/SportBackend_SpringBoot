package com.project.sport.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.sport.models.Player;
import com.project.sport.repository.PlayerRepository;

@Service
public class PlayerServiceImpl implements PlayerService {
	@Autowired
	private PlayerRepository playerRepository;

	@Override
	public List<Player> getAllPlayers() {
		return playerRepository.findAll() ;
	}

	@Override
	public Player updatePlayer(Player players) {
		return playerRepository.save(players);
	}

	@Override
	public void deletePlayer(Integer id) {
		playerRepository.deleteById(id);
	}

	@Override
	public Player addPlayer(Player player) {
		return playerRepository.save(player);
	}

	@Override
	public Player findById(Integer id) {
		 Optional<Player> players = playerRepository.findById(id);
	     return  players.isPresent() ? players.get() : null;
	}

}
