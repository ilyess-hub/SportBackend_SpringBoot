package com.project.sport.models;

public class AuthBean {
	
	private String message;

	public AuthBean() {
		super();
	}
	
	

	public AuthBean(String message) {
		super();
		this.message = message;
	}



	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	} 
	

}
