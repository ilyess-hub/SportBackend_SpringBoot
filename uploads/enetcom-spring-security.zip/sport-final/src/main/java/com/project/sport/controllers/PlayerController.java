package com.project.sport.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.sport.models.Player;
import com.project.sport.services.PlayerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("api/players")
public class PlayerController {

	@Autowired
	private PlayerService playerService;
	
	
	@GetMapping("")
    public List<Player> getAllPlayers(){
	   return playerService.getAllPlayers();
}
    @PutMapping("/{id}")
	public Player update(@PathVariable Integer id ,@RequestBody Player player) {
    	return playerService.updatePlayer(player);
	}
    @DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
    	playerService.deletePlayer(id);
    }
    @PostMapping
	public Player  add(@RequestBody Player player) {
    	return playerService.addPlayer(player);
    }
    @GetMapping("/{id}")
	public Player  getPlayerById(@PathVariable  Integer id) {
		return playerService.findById(id);
	}

}


