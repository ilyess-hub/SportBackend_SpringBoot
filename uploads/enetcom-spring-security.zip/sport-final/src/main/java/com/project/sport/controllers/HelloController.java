package com.project.sport.controllers;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.project.sport.models.Player;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("api/hellos")

public class HelloController {

	@RequestMapping(method = RequestMethod.GET, path = "/helloCroco")
	public String helloCroco(){
		return "Hello CrocoCoders";
	}
	
	@GetMapping(path="")
	public Player helloCrocoEmpty(){
		return new Player("Salah empty");
	}
	@GetMapping(path="/hello")
	public Player helloCrocoTest(){
		return new Player("Salah");
	}
	
	@GetMapping(path="/hello/{name}")
	public Player displayByName(@PathVariable String name){
		return new Player(String.format("The name is %s", name));
	}
}
