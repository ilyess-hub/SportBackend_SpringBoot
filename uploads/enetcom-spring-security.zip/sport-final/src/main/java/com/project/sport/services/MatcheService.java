package com.project.sport.services;

import java.util.List;

import com.project.sport.models.Matche;


public interface MatcheService {
	
	public List<Matche> getAllMatches();
	
	public Matche updateMatche(Matche matches);
	
	public void deleteMatche(Integer id);
	
	public Matche  addMatche(Matche matches);

	public Matche findById(Integer id);
}
