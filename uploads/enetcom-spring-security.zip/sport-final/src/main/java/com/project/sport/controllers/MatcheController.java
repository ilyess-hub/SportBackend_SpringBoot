package com.project.sport.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.sport.models.Matche;
import com.project.sport.services.MatcheService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("api/matchs")
public class MatcheController {

	@Autowired
	private MatcheService matcheService;
	
	
	@GetMapping("")
    public List<Matche> getAllMatches(){
	   return matcheService.getAllMatches();
}
    @PutMapping("/{id}")
	public Matche update(@PathVariable Integer id ,@RequestBody Matche player) {
    	return matcheService.updateMatche(player);
	}
    @DeleteMapping("/{id}")
	public void delete(@PathVariable Integer id) {
    	matcheService.deleteMatche(id);
    }
    @PostMapping
	public Matche  add(@RequestBody Matche player) {
    	return matcheService.addMatche(player);
    }
    @GetMapping("/{id}")
	public Matche  getMatcheById(@PathVariable  Integer id) {
		return matcheService.findById(id);
	}

}


