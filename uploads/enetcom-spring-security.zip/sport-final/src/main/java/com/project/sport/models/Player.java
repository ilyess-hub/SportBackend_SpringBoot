package com.project.sport.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Player {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PLAYER_ID")
	private Integer id;
	@Column
	private Integer nbr;
	@Column
	private String nom;

	private String name;
	private Integer age;
	
	public Player(String name) {
		this.name = name ;
	}
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	@Override
	public String toString() {
		return "Player [name=" + name + "]";
	}
	
	
}
